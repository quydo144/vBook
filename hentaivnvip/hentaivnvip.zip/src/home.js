function execute() {
    return Response.success([
        { title: "Hôm nay", input: "https://hentaivnhot.com/truyen-hot/truyen-hentai-hot-hom-nay", script: "gen.js" },
        { title: "Manhwa", input: "https://hentaivnhot.com/the-loai/manhwa", script: "gen.js" },
        { title: "Adult", input: "https://hentaivnhot.com/the-loai/adult", script: "gen.js" },
        { title: "Oneshot", input: "https://hentaivnhot.com/the-loai/oneshot", script: "gen.js" },
        { title: "Full Color", input: "https://hentaivnhot.com/the-loai/full-color", script: "gen.js" },
        { title: "Không Che", input: "https://hentaivnhot.com/the-loai/khong-che", script: "gen.js" },
    ]);
}