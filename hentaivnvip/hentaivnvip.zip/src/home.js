function execute() {
    return Response.success([
        { title: "Hôm nay", input: "https://hentaivnvip.net/truyen-hot/truyen-hentai-hot-hom-nay", script: "gen.js" },
        { title: "Hot Tuần", input: "https://hentaivnvip.net/truyen-hot/truyen-hot-tuan", script: "gen.js" },
        { title: "Manhwa", input: "https://hentaivnvip.net/the-loai/manhwa", script: "gen.js" },
        { title: "Adult", input: "https://hentaivnvip.net/the-loai/adult", script: "gen.js" },
        { title: "Oneshot", input: "https://hentaivnvip.net/the-loai/oneshot", script: "gen.js" },
        { title: "Full Color", input: "https://hentaivnvip.net/the-loai/full-color", script: "gen.js" },
        { title: "Không Che", input: "https://hentaivnvip.net/the-loai/khong-che", script: "gen.js" },
    ]);
}